# vllm bench throughput

## JSON CLI Arguments

--8<-- "docs/cli/json_tip.inc.md"

## Options

--8<-- "docs/argparse/bench_throughput.md"
